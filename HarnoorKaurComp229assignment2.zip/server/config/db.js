module.exports = 
{
    "URI": "mongodb://localhost/contacts_list",
    "Secret": "SomeSecret"
}