module.exports = 
{
    "URI": "mongodb+srv://Dbuser:data1234@mongo-server.ccjob.mongodb.net/myFirstDatabase?retryWrites=true&w=majority",
    "Secret": "SomeSecret"

}